window.onclick = function(element){
   var panel = element.target.nextElementSibling;


switch(element.target.id){
    case 'accPanel1':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel2':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel3':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel4':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel5':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel6':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel7':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    
    break;
    case 'accPanel8':
        if(panel.style.height == "30px"){
            panel.style.height = "0px";
        }else{
            panel.style.height = "30px";
        }
    break;
}
}